#!/bin/bash
tar -czf mytar_dir.tar.gz /home/mobaxterm/bash
