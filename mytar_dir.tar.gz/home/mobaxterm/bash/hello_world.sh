#!/bin/bash
#declare string variable
STRING="HELLO WORLD"
#print variable on the screen
echo $STRING
